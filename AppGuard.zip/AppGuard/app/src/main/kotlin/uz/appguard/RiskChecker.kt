package uz.appguard

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/** Ўрнатилган иловани оддий қоидалар билан текширади. */
object RiskChecker {

    private val TRUSTED_INSTALLERS = setOf(
        "com.android.vending",            // Google Play
        "com.sec.android.app.samsungapps",// Galaxy Store
        "com.huawei.appmarket",           // AppGallery
        "com.xiaomi.mipicks",             // Xiaomi GetApps
        "com.amazon.venezia"              // Amazon Appstore
    )

    // Хавфли ҳисобланадиган рухсатлар ва уларнинг тавсифи
    private val RISKY_PERMISSIONS = linkedMapOf(
        "android.permission.READ_SMS" to "СМС ўқийди",
        "android.permission.RECEIVE_SMS" to "СМС қабул қилади",
        "android.permission.SEND_SMS" to "СМС юборади",
        "android.permission.SYSTEM_ALERT_WINDOW" to "Бошқа иловалар устидан чизади",
        "android.permission.BIND_ACCESSIBILITY_SERVICE" to "Махсус имкониятлар хизмати",
        "android.permission.BIND_DEVICE_ADMIN" to "Қурилма администратори",
        "android.permission.REQUEST_INSTALL_PACKAGES" to "Бошқа APK ўрната олади",
        "android.permission.READ_CALL_LOG" to "Қўнғироқлар тарихини ўқийди",
        "android.permission.RECORD_AUDIO" to "Микрофондан фойдаланади",
        "android.permission.READ_CONTACTS" to "Контактларни ўқийди"
    )

    fun installerOf(ctx: Context, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) {
            ctx.packageManager.getInstallSourceInfo(pkg).installingPackageName
        } else {
            @Suppress("DEPRECATION")
            ctx.packageManager.getInstallerPackageName(pkg)
        }
    } catch (e: Exception) {
        null
    }

    fun labelOf(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun packageInfo(ctx: Context, pkg: String): PackageInfo? = try {
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.packageManager.getPackageInfo(
                pkg, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            ctx.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
        }
    } catch (e: Exception) {
        null
    }

    /** Хавфли белгилар рўйхатини қайтаради (бўш бўлса — шубҳали ҳолат йўқ). */
    fun risksOf(ctx: Context, pkg: String): List<String> {
        val risks = ArrayList<String>()

        val installer = installerOf(ctx, pkg)
        if (installer == null) {
            risks.add("Расмий дўкондан ташқари ўрнатилган (APK файл орқали)")
        } else if (installer !in TRUSTED_INSTALLERS) {
            risks.add("Ишончли дўкон эмас: $installer")
        }

        val requested = packageInfo(ctx, pkg)?.requestedPermissions?.toSet() ?: emptySet()
        for ((perm, text) in RISKY_PERMISSIONS) {
            if (perm in requested) risks.add(text)
        }
        return risks
    }

    fun installerName(installer: String?): String = when (installer) {
        null -> "APK файл / номаълум"
        "com.android.vending" -> "Google Play"
        "com.sec.android.app.samsungapps" -> "Galaxy Store"
        "com.huawei.appmarket" -> "AppGallery"
        "com.xiaomi.mipicks" -> "Xiaomi GetApps"
        "com.google.android.packageinstaller",
        "com.android.packageinstaller" -> "Тизим ўрнатувчиси (APK файл)"
        else -> installer
    }
}
