package uz.appguard

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var list: ListView
    private lateinit var empty: TextView
    private lateinit var adapter: EventAdapter

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        if (EventStore.isEnabled(this)) MonitorService.start(this)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(MonitorService.ACTION_UPDATED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(updateReceiver, filter)
        }
        refresh()
    }

    override fun onStop() {
        unregisterReceiver(updateReceiver)
        super.onStop()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }

        val title = TextView(this).apply {
            text = "APK Қўриқчи"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Янги иловалар ўрнатилиши, янгиланиши ва ўчирилишини кузатади. " +
                "Барча маълумот фақат шу телефонда сақланади."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(sub)

        val sw = Switch(this).apply {
            text = "Кузатув ёқилган"
            isChecked = EventStore.isEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                EventStore.setEnabled(this@MainActivity, on)
                if (on) MonitorService.start(this@MainActivity) else MonitorService.stop(this@MainActivity)
            }
        }
        root.addView(sw)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val btnInstalled = Button(this).apply {
            text = "Ўрнатилганлар"
            setOnClickListener { showInstalledApps() }
        }
        val btnClear = Button(this).apply {
            text = "Тарихни тозалаш"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("Ҳодисалар тарихи ўчирилсинми?")
                    .setPositiveButton("Ҳа") { _, _ ->
                        EventStore.clear(this@MainActivity)
                        refresh()
                    }
                    .setNegativeButton("Йўқ", null)
                    .show()
            }
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        buttons.addView(btnInstalled, lp)
        buttons.addView(btnClear, LinearLayout.LayoutParams(lp))
        root.addView(buttons)

        empty = TextView(this).apply {
            text = "Ҳали ҳодиса йўқ.\nЯнги илова ўрнатсангиз, бу ерда кўринади."
            gravity = Gravity.CENTER
            setPadding(0, dp(40), 0, 0)
            setTextColor(Color.GRAY)
        }
        root.addView(empty)

        adapter = EventAdapter()
        list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun refresh() {
        adapter.items = EventStore.all(this)
        adapter.notifyDataSetChanged()
        empty.visibility = if (adapter.items.isEmpty()) View.VISIBLE else View.GONE
    }

    /** Фойдаланувчи ўрнатган иловалар ва уларнинг манбаси. */
    private fun showInstalledApps() {
        val pm = packageManager
        @Suppress("DEPRECATION")
        val apps = pm.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val lines = apps.map {
            val src = RiskChecker.installerName(RiskChecker.installerOf(this, it.packageName))
            val flag = if (RiskChecker.risksOf(this, it.packageName).isNotEmpty()) "⚠ " else "✓ "
            "$flag${it.loadLabel(pm)}\n    $src"
        }

        AlertDialog.Builder(this)
            .setTitle("Ўрнатилган иловалар (${apps.size})")
            .setItems(lines.toTypedArray(), null)
            .setPositiveButton("Ёпиш", null)
            .show()
    }

    inner class EventAdapter : BaseAdapter() {
        var items: List<AppEvent> = emptyList()
        private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val e = items[position]
            val tv = (convertView as? TextView) ?: TextView(this@MainActivity).apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                textSize = 14f
            }

            val (word, color) = when (e.type) {
                "ADDED" -> "ЎРНАТИЛДИ" to Color.parseColor("#2E7D32")
                "REPLACED" -> "ЯНГИЛАНДИ" to Color.parseColor("#1565C0")
                else -> "ЎЧИРИЛДИ" to Color.parseColor("#B71C1C")
            }

            val sb = StringBuilder()
            sb.append(word).append("  ·  ").append(fmt.format(Date(e.time))).append('\n')
            sb.append(e.label).append('\n').append(e.pkg)
            if (e.type != "REMOVED") sb.append("\nМанба: ").append(e.installer)
            if (e.risks.isNotEmpty()) sb.append("\n⚠ ").append(e.risks.joinToString("\n⚠ "))

            tv.text = sb.toString()
            tv.setTextColor(Color.BLACK)
            tv.setBackgroundColor(
                if (e.risks.isNotEmpty() && e.type != "REMOVED") Color.parseColor("#FFF3E0") else Color.TRANSPARENT
            )
            tv.tag = color
            return tv
        }
    }
}
