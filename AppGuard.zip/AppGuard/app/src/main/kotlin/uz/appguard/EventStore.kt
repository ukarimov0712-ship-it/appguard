package uz.appguard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Кузатув ҳодисаси: ўрнатилди / янгиланди / ўчирилди. */
data class AppEvent(
    val type: String,        // ADDED, REPLACED, REMOVED
    val pkg: String,
    val label: String,
    val installer: String,   // ўрнатган манба (масалан, com.android.vending)
    val risks: List<String>, // хавфли белгилар
    val time: Long
)

/** Ҳодисаларни телефоннинг ўзида (SharedPreferences) сақлайди. Ташқарига ҳеч нарса юборилмайди. */
object EventStore {
    private const val PREFS = "appguard_events"
    private const val KEY = "events"
    private const val MAX = 300

    @Synchronized
    fun add(ctx: Context, e: AppEvent) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        val obj = JSONObject()
            .put("type", e.type)
            .put("pkg", e.pkg)
            .put("label", e.label)
            .put("installer", e.installer)
            .put("risks", JSONArray(e.risks))
            .put("time", e.time)

        // Янги ҳодиса рўйхат бошида турсин
        val out = JSONArray().put(obj)
        for (i in 0 until minOf(arr.length(), MAX - 1)) out.put(arr.get(i))
        prefs.edit().putString(KEY, out.toString()).apply()
    }

    @Synchronized
    fun all(ctx: Context): List<AppEvent> {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        val list = ArrayList<AppEvent>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val r = o.optJSONArray("risks") ?: JSONArray()
            list.add(
                AppEvent(
                    type = o.optString("type"),
                    pkg = o.optString("pkg"),
                    label = o.optString("label"),
                    installer = o.optString("installer"),
                    risks = (0 until r.length()).map { r.getString(it) },
                    time = o.optLong("time")
                )
            )
        }
        return list
    }

    @Synchronized
    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    // Кузатув ёқилган/ўчирилганини эслаб қолиш
    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", on).apply()
    }

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", true)
}
