package uz.appguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder

/**
 * Иловаларни ўрнатиш/янгилаш/ўчиришни кузатувчи хизмат.
 * Android 8+ да бу ҳодисалар манифестда эълон қилинмайди, шунинг учун
 * хизмат ичида рўйхатдан ўтказилади ва доимий хабарнома билан ишлайди.
 */
class MonitorService : Service() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val pkg = intent.data?.schemeSpecificPart ?: return
            if (pkg == context.packageName) return

            val replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
            val type = when (intent.action) {
                Intent.ACTION_PACKAGE_ADDED -> if (replacing) return else "ADDED" // янгиланишда REPLACED келади
                Intent.ACTION_PACKAGE_REPLACED -> "REPLACED"
                Intent.ACTION_PACKAGE_REMOVED -> if (replacing) return else "REMOVED"
                else -> return
            }

            val label: String
            val installer: String
            val risks: List<String>
            if (type == "REMOVED") {
                // Ўчирилган илованинг маълумотини олиб бўлмайди
                label = lastKnownLabel(pkg)
                installer = "-"
                risks = emptyList()
            } else {
                label = RiskChecker.labelOf(context, pkg)
                installer = RiskChecker.installerName(RiskChecker.installerOf(context, pkg))
                risks = RiskChecker.risksOf(context, pkg)
            }

            val event = AppEvent(type, pkg, label, installer, risks, System.currentTimeMillis())
            EventStore.add(context, event)
            notifyEvent(context, event)
            sendBroadcast(Intent(ACTION_UPDATED).setPackage(packageName))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(ID_FOREGROUND, foregroundNotification())

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(receiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun lastKnownLabel(pkg: String): String =
        EventStore.all(this).firstOrNull { it.pkg == pkg }?.label ?: pkg

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Кузатув ҳолати", NotificationManager.IMPORTANCE_MIN)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_EVENTS, "Иловалар ўзгариши", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun openAppIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    @Suppress("DEPRECATION")
    private fun builder(ctx: Context, channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, channel) else Notification.Builder(ctx)

    private fun foregroundNotification(): Notification =
        builder(this, CH_SERVICE)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("APK Қўриқчи ишламоқда")
            .setContentText("Янги иловалар ўрнатилиши кузатиляпти")
            .setContentIntent(openAppIntent(this))
            .setOngoing(true)
            .build()

    private fun notifyEvent(ctx: Context, e: AppEvent) {
        val title = when (e.type) {
            "ADDED" -> "Янги илова ўрнатилди"
            "REPLACED" -> "Илова янгиланди"
            else -> "Илова ўчирилди"
        } + if (e.risks.isNotEmpty() && e.type != "REMOVED") " ⚠" else ""

        val text = buildString {
            append(e.label).append(" (").append(e.pkg).append(")")
            if (e.type != "REMOVED") append("\nМанба: ").append(e.installer)
            if (e.risks.isNotEmpty()) append("\nДиққат: ").append(e.risks.joinToString("; "))
        }

        val n = builder(ctx, CH_EVENTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText("${e.label} (${e.pkg})")
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openAppIntent(ctx))
            .setAutoCancel(true)
            .build()

        ctx.getSystemService(NotificationManager::class.java)
            .notify((e.time % Int.MAX_VALUE).toInt(), n)
    }

    companion object {
        const val ACTION_UPDATED = "uz.appguard.EVENTS_UPDATED"
        private const val CH_SERVICE = "appguard_service"
        private const val CH_EVENTS = "appguard_events"
        private const val ID_FOREGROUND = 1

        fun start(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MonitorService::class.java))
        }
    }
}
