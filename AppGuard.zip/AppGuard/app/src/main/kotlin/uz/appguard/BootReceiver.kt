package uz.appguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Телефон қайта ёқилганда, агар кузатув ёқиқ бўлса, хизматни қайта ишга туширади. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && EventStore.isEnabled(context)) {
            MonitorService.start(context)
        }
    }
}
